-- ============================================================
-- Trade Processing Engine - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS trade_engine;
USE trade_engine;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(64) NOT NULL UNIQUE,
    email       VARCHAR(128) NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Immutable execution log - never update, only insert
CREATE TABLE IF NOT EXISTS trades (
    trade_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         BIGINT NOT NULL,
    ticker          VARCHAR(16) NOT NULL,
    side            ENUM('BUY', 'SELL') NOT NULL,
    quantity        BIGINT NOT NULL,          -- always positive
    price           DECIMAL(18, 6) NOT NULL,
    executed_at     DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    latency_ms      BIGINT,                   -- processing latency log
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- FIFO lot tracker - one row per buy lot remaining
CREATE TABLE IF NOT EXISTS lots (
    lot_id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    trade_id        BIGINT NOT NULL,
    user_id         BIGINT NOT NULL,
    ticker          VARCHAR(16) NOT NULL,
    quantity_open   BIGINT NOT NULL,          -- decremented as shares are sold
    cost_per_share  DECIMAL(18, 6) NOT NULL,
    opened_at       DATETIME(3) NOT NULL,
    FOREIGN KEY (trade_id) REFERENCES trades(trade_id),
    INDEX idx_lots_user_ticker (user_id, ticker, opened_at)
);

-- Current position state (cache to avoid full trade replay on every read)
CREATE TABLE IF NOT EXISTS positions (
    user_id         BIGINT NOT NULL,
    ticker          VARCHAR(16) NOT NULL,
    net_quantity    BIGINT NOT NULL DEFAULT 0,   -- negative = short
    realized_pnl    DECIMAL(18, 6) NOT NULL DEFAULT 0,
    last_updated    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (user_id, ticker),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Simulated market price feed (updated by background price-feed thread)
CREATE TABLE IF NOT EXISTS market_data (
    ticker          VARCHAR(16) PRIMARY KEY,
    last_price      DECIMAL(18, 6) NOT NULL,
    prev_price      DECIMAL(18, 6) NOT NULL,
    updated_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
);

-- Seed market data
INSERT INTO market_data (ticker, last_price, prev_price) VALUES
    ('AAPL', 185.00, 185.00),
    ('TSLA', 175.00, 175.00),
    ('GOOGL', 160.00, 160.00),
    ('MSFT', 415.00, 415.00),
    ('NVDA', 870.00, 870.00),
    ('AMZN', 185.00, 185.00)
ON DUPLICATE KEY UPDATE last_price = VALUES(last_price);

-- Seed test users
INSERT INTO users (username, email) VALUES
    ('alice',   'alice@example.com'),
    ('bob',     'bob@example.com'),
    ('charlie', 'charlie@example.com')
ON DUPLICATE KEY UPDATE email = VALUES(email);
