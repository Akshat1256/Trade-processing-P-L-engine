package com.tradeengine.pool;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton HikariCP connection pool.
 * Configured for low-latency OLTP workloads.
 */
public class ConnectionPool {

    private static final Logger log = LoggerFactory.getLogger(ConnectionPool.class);
    private static volatile HikariDataSource instance;

    private ConnectionPool() {}

    public static DataSource get() {
        if (instance == null) {
            synchronized (ConnectionPool.class) {
                if (instance == null) {
                    instance = buildPool();
                }
            }
        }
        return instance;
    }

    private static HikariDataSource buildPool() {
        Properties props = loadProperties();

        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(props.getProperty("db.url",
                "jdbc:mysql://localhost:3306/trade_engine?useSSL=false&serverTimezone=UTC"));
        cfg.setUsername(props.getProperty("db.user", "root"));
        cfg.setPassword(props.getProperty("db.password", ""));
        cfg.setDriverClassName("com.mysql.cj.jdbc.Driver");

        // Pool sizing: for HFT-adjacent loads, keep pool tight to avoid contention
        cfg.setMaximumPoolSize(20);
        cfg.setMinimumIdle(5);
        cfg.setConnectionTimeout(3_000);      // 3s to get connection from pool
        cfg.setIdleTimeout(600_000);
        cfg.setMaxLifetime(1_800_000);
        cfg.setPoolName("TradeEnginePool");

        // Critical for P&L accuracy: use UTC everywhere
        cfg.addDataSourceProperty("connectionInitSql",
                "SET time_zone = '+00:00'");

        // Performance tuning
        cfg.addDataSourceProperty("cachePrepStmts", "true");
        cfg.addDataSourceProperty("prepStmtCacheSize", "250");
        cfg.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        cfg.addDataSourceProperty("useServerPrepStmts", "true");
        cfg.addDataSourceProperty("rewriteBatchedStatements", "true"); // enables batch inserts

        log.info("Initializing HikariCP pool: maxPoolSize={}", cfg.getMaximumPoolSize());
        return new HikariDataSource(cfg);
    }

    private static Properties loadProperties() {
        Properties p = new Properties();
        try (InputStream in = ConnectionPool.class
                .getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) p.load(in);
        } catch (IOException e) {
            log.warn("db.properties not found, using defaults");
        }
        return p;
    }

    public static void shutdown() {
        if (instance != null && !instance.isClosed()) {
            instance.close();
            log.info("Connection pool shut down");
        }
    }
}
