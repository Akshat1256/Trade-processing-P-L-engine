package com.tradeengine.engine;

import com.tradeengine.db.MarketDataRepository;
import com.tradeengine.db.TradeRepository;
import com.tradeengine.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Core Trade Processing Engine.
 *
 * Thread Safety Design:
 * - One ReentrantLock per userId prevents two simultaneous trades for the same user
 *   from corrupting their position (race condition on lot consumption).
 * - Different users can trade fully concurrently.
 * - ConcurrentHashMap ensures the lock map itself is thread-safe.
 * - All DB mutations wrapped in a single JDBC transaction (autoCommit=false).
 *   If any step fails, everything rolls back — trades log and position stay consistent.
 *
 * Financial Precision:
 * - All monetary math uses BigDecimal with HALF_UP rounding.
 * - Never float. Never double.
 */
public class TradeEngine {

    private static final Logger log = LoggerFactory.getLogger(TradeEngine.class);

    private final DataSource ds;
    private final TradeRepository tradeRepo;
    private final MarketDataRepository marketRepo;

    // Per-user lock map — ensures no two threads process the same user simultaneously
    private final ConcurrentHashMap<Long, ReentrantLock> userLocks = new ConcurrentHashMap<>();

    public TradeEngine(DataSource ds) {
        this.ds = ds;
        this.tradeRepo = new TradeRepository();
        this.marketRepo = new MarketDataRepository(ds);
    }

    // ---------------------------------------------------------------
    // Primary execution path
    // ---------------------------------------------------------------

    /**
     * Processes a trade execution end-to-end:
     * 1. Validates the trade
     * 2. Acquires per-user lock
     * 3. Starts DB transaction
     * 4. Persists trade to immutable log
     * 5. Updates FIFO lots
     * 6. Upserts position
     * 7. Commits — or rolls back on any failure
     *
     * @return TradeResult with realized P&L and latency
     */
    public TradeResult process(Trade trade) {
        long startNs = System.nanoTime();
        validateTrade(trade);

        ReentrantLock lock = userLocks.computeIfAbsent(trade.userId(), id -> new ReentrantLock());
        lock.lock();
        try {
            return executeWithTransaction(trade, startNs);
        } finally {
            lock.unlock();
        }
    }

    private TradeResult executeWithTransaction(Trade trade, long startNs) {
        try (Connection conn = ds.getConnection()) {
            conn.setAutoCommit(false);  // BEGIN TRANSACTION
            try {
                long latencyMs = (System.nanoTime() - startNs) / 1_000_000;

                // Step 1: Write to immutable trade log
                long tradeId = tradeRepo.insertTrade(conn, trade, latencyMs);

                // Step 2 & 3: Update lots and position (side-specific)
                BigDecimal realizedPnl;
                if (trade.side() == Side.BUY) {
                    tradeRepo.insertLot(conn, tradeId, trade);
                    tradeRepo.upsertPosition(conn, trade.userId(), trade.ticker(),
                            trade.quantity(), BigDecimal.ZERO);
                    realizedPnl = BigDecimal.ZERO;
                } else {
                    // FIFO: consume oldest lots first, compute realized P&L
                    realizedPnl = tradeRepo.consumeLotsFifo(conn, trade);
                    tradeRepo.upsertPosition(conn, trade.userId(), trade.ticker(),
                            -trade.quantity(), realizedPnl);
                }

                conn.commit();  // COMMIT — all or nothing

                long totalLatencyMs = (System.nanoTime() - startNs) / 1_000_000;
                TradeResult result = new TradeResult(
                        tradeId, trade.userId(), trade.ticker(), trade.side(),
                        trade.quantity(), trade.price(), realizedPnl, totalLatencyMs
                );

                log.info("Trade processed in {}ms: {}", totalLatencyMs, result);
                return result;

            } catch (SQLException e) {
                conn.rollback();  // ROLLBACK on any DB error
                log.error("Trade failed — rolled back. Trade: {}", trade, e);
                throw new TradeException("Trade processing failed: " + e.getMessage(), e);
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            throw new TradeException("Could not obtain DB connection", e);
        }
    }

    // ---------------------------------------------------------------
    // Batch processing
    // ---------------------------------------------------------------

    /**
     * Processes a batch of trades in a single pass.
     * Trades for different users run concurrently (Java 21 virtual threads).
     * Uses per-user locking so same-user trades are still serialized.
     */
    public List<TradeResult> processBatch(List<Trade> trades) {
        log.info("Processing batch of {} trades", trades.size());
        // Virtual threads: each trade gets its own lightweight thread
        try (var executor = java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor()) {
            List<java.util.concurrent.Future<TradeResult>> futures = trades.stream()
                    .map(t -> executor.submit(() -> process(t)))
                    .toList();

            List<TradeResult> results = new ArrayList<>();
            for (var f : futures) {
                try {
                    results.add(f.get());
                } catch (Exception e) {
                    log.error("Batch trade failed", e);
                }
            }
            return results;
        }
    }

    // ---------------------------------------------------------------
    // Portfolio / P&L queries
    // ---------------------------------------------------------------

    /**
     * Returns the full portfolio for a user:
     * - Each position with FIFO avg cost basis
     * - Realized P&L from closed lots
     * - Unrealized P&L = (LTP - avgCost) * qty (mark-to-market)
     */
    public List<Holding> getPortfolio(long userId) {
        try (Connection conn = ds.getConnection()) {
            List<TradeRepository.PositionRow> rows = tradeRepo.getPositions(conn, userId);
            List<Holding> holdings = new ArrayList<>();

            for (TradeRepository.PositionRow row : rows) {
                BigDecimal avgCost = tradeRepo.getAvgCostBasis(conn, userId, row.ticker());
                BigDecimal ltp = row.lastPrice();

                // Unrealized P&L: MTM on open position
                BigDecimal unrealized = ltp
                        .subtract(avgCost)
                        .multiply(BigDecimal.valueOf(row.netQuantity()))
                        .setScale(6, RoundingMode.HALF_UP);

                holdings.add(new Holding(
                        row.ticker(),
                        row.netQuantity(),
                        row.realizedPnl(),
                        unrealized,
                        ltp,
                        avgCost
                ));
            }
            return holdings;
        } catch (SQLException e) {
            throw new TradeException("Portfolio fetch failed", e);
        }
    }

    // ---------------------------------------------------------------
    // Validation
    // ---------------------------------------------------------------

    private void validateTrade(Trade trade) {
        // Trade constructor already validates qty > 0, price > 0, ticker not blank
        // Additional business rules:
        try {
            BigDecimal ltp = marketRepo.getLastPrice(trade.ticker());
            if (ltp == null) {
                throw new TradeException("Unknown ticker: " + trade.ticker());
            }
            // Sanity check: reject trades more than 20% away from LTP (circuit breaker)
            BigDecimal pctDiff = trade.price().subtract(ltp)
                    .abs()
                    .divide(ltp, 4, RoundingMode.HALF_UP);
            if (pctDiff.compareTo(new BigDecimal("0.20")) > 0) {
                throw new TradeException(String.format(
                        "Price $%s is >20%% away from LTP $%s for %s — trade rejected",
                        trade.price(), ltp, trade.ticker()));
            }
        } catch (SQLException e) {
            throw new TradeException("Validation failed: cannot fetch market data", e);
        }
    }

    // ---------------------------------------------------------------
    // Runtime exception wrapper
    // ---------------------------------------------------------------

    public static class TradeException extends RuntimeException {
        public TradeException(String msg) { super(msg); }
        public TradeException(String msg, Throwable cause) { super(msg, cause); }
    }
}
