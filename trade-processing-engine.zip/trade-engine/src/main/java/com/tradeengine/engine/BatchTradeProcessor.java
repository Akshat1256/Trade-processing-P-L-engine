package com.tradeengine.engine;

import com.tradeengine.model.Trade;
import com.tradeengine.model.TradeResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * Buffers incoming trades and flushes them in batches.
 *
 * Two flush triggers:
 * 1. Buffer reaches BATCH_SIZE (100 trades)
 * 2. Flush interval elapses (100ms default)
 *
 * Useful for bulk simulation scenarios where throughput
 * matters more than individual trade latency.
 */
public class BatchTradeProcessor implements AutoCloseable {

    private static final Logger log = LoggerFactory.getLogger(BatchTradeProcessor.class);
    private static final int BATCH_SIZE = 100;
    private static final long FLUSH_INTERVAL_MS = 100;

    private final TradeEngine engine;
    private final List<Trade> buffer = new ArrayList<>();
    private final ScheduledExecutorService flusher;
    private final List<TradeResult> results = new CopyOnWriteArrayList<>();

    public BatchTradeProcessor(DataSource ds) {
        this.engine = new TradeEngine(ds);
        this.flusher = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "batch-flusher");
            t.setDaemon(true);
            return t;
        });
        flusher.scheduleAtFixedRate(this::flushIfNeeded,
                FLUSH_INTERVAL_MS, FLUSH_INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    /** Adds a trade to the buffer. Flushes immediately if buffer is full. */
    public synchronized void submit(Trade trade) {
        buffer.add(trade);
        if (buffer.size() >= BATCH_SIZE) {
            flush();
        }
    }

    /** Manually flush remaining buffered trades. */
    public synchronized List<TradeResult> flush() {
        if (buffer.isEmpty()) return List.of();
        List<Trade> batch = new ArrayList<>(buffer);
        buffer.clear();
        log.info("Flushing batch of {} trades", batch.size());
        List<TradeResult> batchResults = engine.processBatch(batch);
        results.addAll(batchResults);
        return batchResults;
    }

    public List<TradeResult> getAllResults() {
        return List.copyOf(results);
    }

    private void flushIfNeeded() {
        synchronized (this) {
            if (!buffer.isEmpty()) flush();
        }
    }

    @Override
    public void close() {
        flush();
        flusher.shutdown();
    }
}
