package com.tradeengine.cli;

import com.tradeengine.engine.TradeEngine;
import com.tradeengine.feed.PriceFeedSimulator;
import com.tradeengine.model.Holding;
import com.tradeengine.model.Side;
import com.tradeengine.model.Trade;
import com.tradeengine.model.TradeResult;
import com.tradeengine.pool.ConnectionPool;
import com.tradeengine.util.LatencyTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Scanner;

/**
 * Interactive command-line interface for the Trade Processing Engine.
 *
 * Commands:
 *   trade <userId> <BUY|SELL> <qty> <ticker> <price>
 *   portfolio <userId>
 *   prices
 *   latency
 *   reconcile
 *   quit
 */
public class TradeCLI {

    private static final Logger log = LoggerFactory.getLogger(TradeCLI.class);

    private static TradeEngine engine;
    private static PriceFeedSimulator priceFeed;
    private static LatencyTracker latencyTracker;

    public static void main(String[] args) throws Exception {
        DataSource ds = ConnectionPool.get();
        engine = new TradeEngine(ds);
        priceFeed = new PriceFeedSimulator(ds);
        latencyTracker = new LatencyTracker();

        priceFeed.start();
        printBanner();

        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isBlank()) continue;
            try {
                if (!handleCommand(line)) break;
            } catch (Exception e) {
                System.out.println("[ERROR] " + e.getMessage());
            }
        }

        priceFeed.stop();
        ConnectionPool.shutdown();
        System.out.println("Goodbye.");
    }

    private static boolean handleCommand(String line) {
        String[] parts = line.split("\\s+");
        String cmd = parts[0].toLowerCase();

        switch (cmd) {
            case "trade" -> {
                if (parts.length < 6) {
                    System.out.println("Usage: trade <userId> <BUY|SELL> <qty> <ticker> <price>");
                    return true;
                }
                long userId = Long.parseLong(parts[1]);
                Side side = Side.valueOf(parts[2].toUpperCase());
                long qty = Long.parseLong(parts[3]);
                String ticker = parts[4].toUpperCase();
                BigDecimal price = new BigDecimal(parts[5]);

                Trade trade = new Trade(userId, ticker, side, qty, price);
                TradeResult result = engine.process(trade);
                latencyTracker.record(result.latencyMillis());
                System.out.println(result);
            }
            case "portfolio" -> {
                if (parts.length < 2) {
                    System.out.println("Usage: portfolio <userId>");
                    return true;
                }
                long userId = Long.parseLong(parts[1]);
                List<Holding> holdings = engine.getPortfolio(userId);
                printPortfolio(userId, holdings);
            }
            case "prices" -> {
                System.out.println("\n--- Current Market Prices ---");
                try {
                    var allPrices = new com.tradeengine.db.MarketDataRepository(ConnectionPool.get()).getAllPrices();
                    allPrices.forEach((t, p) -> System.out.printf("  %-6s  $%s%n", t, p.setScale(2, RoundingMode.HALF_UP)));
                } catch (Exception e) {
                    System.out.println("[ERROR] " + e.getMessage());
                }
                System.out.println();
            }
            case "latency" -> latencyTracker.logSummary();
            case "reconcile" -> {
                System.out.println("Running reconciliation from trade log...");
                try (var conn = ConnectionPool.get().getConnection()) {
                    new com.tradeengine.db.TradeRepository().reconcilePositions(conn);
                    System.out.println("Reconciliation complete.");
                } catch (Exception e) {
                    System.out.println("[ERROR] Reconciliation failed: " + e.getMessage());
                }
            }
            case "demo" -> runDemo();
            case "help" -> printHelp();
            case "quit", "exit", "q" -> { return false; }
            default -> System.out.println("Unknown command: " + cmd + ". Type 'help' for commands.");
        }
        return true;
    }

    private static void printPortfolio(long userId, List<Holding> holdings) {
        System.out.println("\n╔══════════════════════════════════════════════════════════════════════╗");
        System.out.printf( "║  Portfolio for User %d%n", userId);
        System.out.println("╠══════════════════════════════════════════════════════════════════════╣");
        if (holdings.isEmpty()) {
            System.out.println("║  No open positions.");
        } else {
            System.out.printf("║  %-6s  %-5s  %6s  %-12s  %-12s  %-12s  %-12s  %s%n",
                    "Ticker", "Side", "Qty", "AvgCost", "LTP", "Realized", "Unrealized", "Total P&L");
            System.out.println("║  " + "─".repeat(80));
            BigDecimal totalPnl = BigDecimal.ZERO;
            for (Holding h : holdings) {
                System.out.println("║" + h);
                totalPnl = totalPnl.add(h.totalPnl());
            }
            System.out.println("║  " + "─".repeat(80));
            System.out.printf("║  Total Portfolio P&L: $%s%n",
                    totalPnl.setScale(2, RoundingMode.HALF_UP).toPlainString());
        }
        System.out.println("╚══════════════════════════════════════════════════════════════════════╝\n");
    }

    private static void runDemo() {
        System.out.println("\n>>> Running demo: simulating trades for user 1...\n");
        try {
            // BUY 100 AAPL @ market
            BigDecimal aaplPrice = priceFeed.getLatestPrice("AAPL");
            if (aaplPrice == null) aaplPrice = new BigDecimal("185.00");

            Trade buy1 = new Trade(1, "AAPL", Side.BUY, 100, aaplPrice);
            System.out.println("  " + engine.process(buy1));

            Thread.sleep(300);

            // BUY more AAPL at a different price (tests FIFO across two lots)
            Trade buy2 = new Trade(1, "AAPL", Side.BUY, 50, aaplPrice.add(new BigDecimal("2.50")));
            System.out.println("  " + engine.process(buy2));

            Thread.sleep(300);

            // BUY TSLA
            BigDecimal tslaPrice = priceFeed.getLatestPrice("TSLA");
            if (tslaPrice == null) tslaPrice = new BigDecimal("175.00");
            Trade buy3 = new Trade(1, "TSLA", Side.BUY, 50, tslaPrice);
            System.out.println("  " + engine.process(buy3));

            Thread.sleep(500);

            // SELL some AAPL — should trigger FIFO realized P&L
            BigDecimal sellPrice = priceFeed.getLatestPrice("AAPL");
            if (sellPrice == null) sellPrice = aaplPrice.add(new BigDecimal("5.00"));
            Trade sell1 = new Trade(1, "AAPL", Side.SELL, 80, sellPrice);
            System.out.println("  " + engine.process(sell1));

            Thread.sleep(200);

            // Show resulting portfolio
            List<Holding> holdings = engine.getPortfolio(1L);
            printPortfolio(1, holdings);

        } catch (Exception e) {
            System.out.println("[ERROR] Demo failed: " + e.getMessage());
        }
    }

    private static void printBanner() {
        System.out.println("""
            ╔══════════════════════════════════════════════════╗
            ║        Trade Processing Engine  v1.0.0           ║
            ║   FIFO P&L · HikariCP · Virtual Threads · MTM   ║
            ╚══════════════════════════════════════════════════╝
            Type 'help' for commands, 'demo' to run a quick simulation.
            """);
    }

    private static void printHelp() {
        System.out.println("""
            Commands:
              trade <userId> <BUY|SELL> <qty> <ticker> <price>
                  e.g. trade 1 BUY 100 AAPL 185.50

              portfolio <userId>
                  Show holdings with realized + unrealized P&L

              prices
                  Show current simulated market prices

              latency
                  Show trade processing latency stats (p50/p95/p99)

              reconcile
                  Rebuild positions from trade log (crash recovery)

              demo
                  Run a quick multi-trade simulation for user 1

              quit
                  Exit the engine
            """);
    }
}
