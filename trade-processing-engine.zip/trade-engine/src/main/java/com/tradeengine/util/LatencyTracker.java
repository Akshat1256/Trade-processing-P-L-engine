package com.tradeengine.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LongSummaryStatistics;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.LongAdder;

/**
 * Tracks trade processing latency.
 * Thread-safe — uses lock-free data structures.
 *
 * Maintains a sliding window of the last N latency measurements
 * for percentile calculation (p50, p95, p99).
 */
public class LatencyTracker {

    private static final Logger log = LoggerFactory.getLogger(LatencyTracker.class);
    private static final int WINDOW_SIZE = 1000;

    private final ConcurrentLinkedQueue<Long> window = new ConcurrentLinkedQueue<>();
    private final LongAdder totalTrades = new LongAdder();
    private final LongAdder totalLatencyMs = new LongAdder();

    public void record(long latencyMs) {
        totalTrades.increment();
        totalLatencyMs.add(latencyMs);

        window.offer(latencyMs);
        // Trim window to WINDOW_SIZE
        while (window.size() > WINDOW_SIZE) {
            window.poll();
        }
    }

    public void logSummary() {
        long[] sorted = window.stream().mapToLong(Long::longValue).sorted().toArray();
        if (sorted.length == 0) {
            log.info("Latency: no data yet");
            return;
        }
        LongSummaryStatistics stats = window.stream()
                .mapToLong(Long::longValue).summaryStatistics();

        log.info("=== Latency Summary (last {} trades) ===", sorted.length);
        log.info("  Trades processed : {}", totalTrades.sum());
        log.info("  Avg latency      : {}ms", totalLatencyMs.sum() / Math.max(1, totalTrades.sum()));
        log.info("  Min / Max        : {}ms / {}ms", stats.getMin(), stats.getMax());
        log.info("  p50              : {}ms", percentile(sorted, 50));
        log.info("  p95              : {}ms", percentile(sorted, 95));
        log.info("  p99              : {}ms", percentile(sorted, 99));
    }

    private long percentile(long[] sorted, int pct) {
        int idx = (int) Math.ceil(pct / 100.0 * sorted.length) - 1;
        return sorted[Math.max(0, Math.min(idx, sorted.length - 1))];
    }
}
