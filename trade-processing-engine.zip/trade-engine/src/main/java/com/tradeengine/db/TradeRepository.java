package com.tradeengine.db;

import com.tradeengine.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * All JDBC operations for trades, lots, and positions.
 *
 * Key design decisions:
 * - No ORM; raw JDBC for maximum control and latency visibility.
 * - Callers pass a Connection to enable transaction composition.
 * - All monetary values use BigDecimal (DECIMAL(18,6) in DB).
 */
public class TradeRepository {

    private static final Logger log = LoggerFactory.getLogger(TradeRepository.class);

    // ---------------------------------------------------------------
    // Trade insertion
    // ---------------------------------------------------------------

    /**
     * Persists a new execution to the immutable trades log.
     * Returns the generated trade_id.
     */
    public long insertTrade(Connection conn, Trade trade, long latencyMs) throws SQLException {
        String sql = """
                INSERT INTO trades (user_id, ticker, side, quantity, price, latency_ms)
                VALUES (?, ?, ?, ?, ?, ?)
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, trade.userId());
            ps.setString(2, trade.ticker());
            ps.setString(3, trade.side().name());
            ps.setLong(4, trade.quantity());
            ps.setBigDecimal(5, trade.price());
            ps.setLong(6, latencyMs);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getLong(1);
                throw new SQLException("No generated key returned for trade insert");
            }
        }
    }

    // ---------------------------------------------------------------
    // FIFO Lot management
    // ---------------------------------------------------------------

    /** Opens a new lot when a BUY is executed. */
    public void insertLot(Connection conn, long tradeId, Trade trade) throws SQLException {
        String sql = """
                INSERT INTO lots (trade_id, user_id, ticker, quantity_open, cost_per_share, opened_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, tradeId);
            ps.setLong(2, trade.userId());
            ps.setString(3, trade.ticker());
            ps.setLong(4, trade.quantity());
            ps.setBigDecimal(5, trade.price());
            ps.setTimestamp(6, Timestamp.from(Instant.now()));
            ps.executeUpdate();
        }
    }

    /**
     * Returns open lots for a user+ticker, oldest first (FIFO order).
     * Only lots with quantity_open > 0 are returned.
     */
    public List<Lot> getOpenLots(Connection conn, long userId, String ticker) throws SQLException {
        String sql = """
                SELECT lot_id, trade_id, user_id, ticker, quantity_open, cost_per_share, opened_at
                FROM lots
                WHERE user_id = ? AND ticker = ? AND quantity_open > 0
                ORDER BY opened_at ASC
                """;
        List<Lot> lots = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setString(2, ticker);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lots.add(new Lot(
                            rs.getLong("lot_id"),
                            rs.getLong("trade_id"),
                            rs.getLong("user_id"),
                            rs.getString("ticker"),
                            rs.getLong("quantity_open"),
                            rs.getBigDecimal("cost_per_share"),
                            rs.getTimestamp("opened_at").toInstant()
                    ));
                }
            }
        }
        return lots;
    }

    /** Decrements a lot's open quantity (partial or full fill). */
    public void reduceLot(Connection conn, long lotId, long quantityConsumed) throws SQLException {
        String sql = "UPDATE lots SET quantity_open = quantity_open - ? WHERE lot_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, quantityConsumed);
            ps.setLong(2, lotId);
            ps.executeUpdate();
        }
    }

    // ---------------------------------------------------------------
    // Position upsert
    // ---------------------------------------------------------------

    /**
     * Upserts the position row for (userId, ticker).
     * On conflict: adds deltaQty to net_quantity and adds realizedPnl to running total.
     *
     * deltaQty is signed: positive for BUY, negative for SELL.
     */
    public void upsertPosition(Connection conn, long userId, String ticker,
                               long deltaQty, BigDecimal realizedPnl) throws SQLException {
        String sql = """
                INSERT INTO positions (user_id, ticker, net_quantity, realized_pnl, last_updated)
                VALUES (?, ?, ?, ?, NOW(3))
                ON DUPLICATE KEY UPDATE
                    net_quantity = net_quantity + VALUES(net_quantity),
                    realized_pnl = realized_pnl + VALUES(realized_pnl),
                    last_updated = NOW(3)
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setString(2, ticker);
            ps.setLong(3, deltaQty);
            ps.setBigDecimal(4, realizedPnl);
            ps.executeUpdate();
        }
    }

    // ---------------------------------------------------------------
    // Portfolio read
    // ---------------------------------------------------------------

    /** Returns all non-zero positions for a user. */
    public List<PositionRow> getPositions(Connection conn, long userId) throws SQLException {
        String sql = """
                SELECT p.ticker, p.net_quantity, p.realized_pnl,
                       COALESCE(m.last_price, 0) AS last_price
                FROM positions p
                LEFT JOIN market_data m ON m.ticker = p.ticker
                WHERE p.user_id = ? AND p.net_quantity != 0
                ORDER BY p.ticker
                """;
        List<PositionRow> rows = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    rows.add(new PositionRow(
                            rs.getString("ticker"),
                            rs.getLong("net_quantity"),
                            rs.getBigDecimal("realized_pnl"),
                            rs.getBigDecimal("last_price")
                    ));
                }
            }
        }
        return rows;
    }

    /** Computes FIFO avg cost from remaining lots for unrealized P&L display. */
    public BigDecimal getAvgCostBasis(Connection conn, long userId, String ticker) throws SQLException {
        String sql = """
                SELECT SUM(quantity_open * cost_per_share) / NULLIF(SUM(quantity_open), 0) AS avg_cost
                FROM lots
                WHERE user_id = ? AND ticker = ? AND quantity_open > 0
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setString(2, ticker);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getBigDecimal("avg_cost") != null) {
                    return rs.getBigDecimal("avg_cost");
                }
            }
        }
        return BigDecimal.ZERO;
    }

    // ---------------------------------------------------------------
    // Reconciliation (crash recovery)
    // ---------------------------------------------------------------

    /**
     * Reconciliation: rebuilds the positions table from scratch by replaying
     * all trades in chronological order. Call on startup after a crash.
     * This is a heavy operation - run offline, not in the hot path.
     */
    public void reconcilePositions(Connection conn) throws SQLException {
        log.info("Starting position reconciliation from trade log...");
        conn.setAutoCommit(false);
        try {
            // 1. Wipe derived tables (lots and positions are derived from trades)
            conn.createStatement().executeUpdate("DELETE FROM lots");
            conn.createStatement().executeUpdate("DELETE FROM positions");

            // 2. Replay all trades in order - simplistic replay (real systems use event sourcing)
            String sql = """
                    SELECT trade_id, user_id, ticker, side, quantity, price, executed_at
                    FROM trades ORDER BY executed_at ASC
                    """;
            try (ResultSet rs = conn.createStatement().executeQuery(sql)) {
                while (rs.next()) {
                    Trade t = new Trade(
                            rs.getLong("user_id"),
                            rs.getString("ticker"),
                            Side.valueOf(rs.getString("side")),
                            rs.getLong("quantity"),
                            rs.getBigDecimal("price")
                    );
                    long tradeId = rs.getLong("trade_id");
                    // Re-apply each trade (simplified - delegates to repository methods)
                    applyTradeToLots(conn, t, tradeId);
                }
            }
            conn.commit();
            log.info("Reconciliation complete.");
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    private void applyTradeToLots(Connection conn, Trade trade, long tradeId) throws SQLException {
        if (trade.side() == Side.BUY) {
            insertLot(conn, tradeId, trade);
            upsertPosition(conn, trade.userId(), trade.ticker(), trade.quantity(), BigDecimal.ZERO);
        } else {
            // SELL: consume lots FIFO, compute realized P&L
            BigDecimal realized = consumeLotsFifo(conn, trade);
            upsertPosition(conn, trade.userId(), trade.ticker(), -trade.quantity(), realized);
        }
    }

    /**
     * Consumes lots FIFO for a SELL trade.
     * Returns total realized P&L for the sell.
     * This is called within a transaction by the caller.
     */
    public BigDecimal consumeLotsFifo(Connection conn, Trade sell) throws SQLException {
        List<Lot> lots = getOpenLots(conn, sell.userId(), sell.ticker());
        long remaining = sell.quantity();
        BigDecimal realizedPnl = BigDecimal.ZERO;

        for (Lot lot : lots) {
            if (remaining <= 0) break;
            long consumed = Math.min(lot.quantityOpen(), remaining);
            // Realized P&L = (sell price - cost basis) * shares sold
            BigDecimal pnl = sell.price()
                    .subtract(lot.costPerShare())
                    .multiply(BigDecimal.valueOf(consumed));
            realizedPnl = realizedPnl.add(pnl);
            reduceLot(conn, lot.lotId(), consumed);
            remaining -= consumed;
        }

        if (remaining > 0) {
            // Going short - no cost basis to match; position becomes negative
            log.warn("SELL of {} {} for user {} exceeds long position by {} shares (short position opened)",
                    sell.quantity(), sell.ticker(), sell.userId(), remaining);
        }

        return realizedPnl;
    }

    /** Internal DTO for position rows read from DB. */
    public record PositionRow(
            String ticker,
            long netQuantity,
            BigDecimal realizedPnl,
            BigDecimal lastPrice
    ) {}
}
