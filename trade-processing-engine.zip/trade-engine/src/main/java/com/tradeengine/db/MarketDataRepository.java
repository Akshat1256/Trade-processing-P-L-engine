package com.tradeengine.db;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class MarketDataRepository {

    private final DataSource ds;

    public MarketDataRepository(DataSource ds) {
        this.ds = ds;
    }

    /** Fetches current LTP for a single ticker. Returns null if not found. */
    public BigDecimal getLastPrice(String ticker) throws SQLException {
        String sql = "SELECT last_price FROM market_data WHERE ticker = ?";
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ticker);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBigDecimal("last_price") : null;
            }
        }
    }

    /** Bulk fetch all prices - used by price feed thread. */
    public Map<String, BigDecimal> getAllPrices() throws SQLException {
        Map<String, BigDecimal> prices = new HashMap<>();
        String sql = "SELECT ticker, last_price FROM market_data";
        try (Connection conn = ds.getConnection();
             ResultSet rs = conn.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                prices.put(rs.getString("ticker"), rs.getBigDecimal("last_price"));
            }
        }
        return prices;
    }

    /** Updates price for a ticker (called by PriceFeedSimulator). */
    public void updatePrice(String ticker, BigDecimal newPrice) throws SQLException {
        String sql = """
                UPDATE market_data
                SET prev_price = last_price, last_price = ?, updated_at = NOW(3)
                WHERE ticker = ?
                """;
        try (Connection conn = ds.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, newPrice);
            ps.setString(2, ticker);
            ps.executeUpdate();
        }
    }
}
