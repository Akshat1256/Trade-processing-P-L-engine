package com.tradeengine.model;

public enum Side {
    BUY, SELL
}
