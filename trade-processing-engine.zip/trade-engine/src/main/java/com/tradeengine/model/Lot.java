package com.tradeengine.model;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * A single open share lot, used for FIFO P&L matching.
 * Lots are consumed (quantity_open decremented) when shares are sold.
 */
public record Lot(
        long lotId,
        long tradeId,
        long userId,
        String ticker,
        long quantityOpen,
        BigDecimal costPerShare,
        Instant openedAt
) {}
