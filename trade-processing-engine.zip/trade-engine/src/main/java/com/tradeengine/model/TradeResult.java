package com.tradeengine.model;

import java.math.BigDecimal;

/**
 * Result returned after a trade is processed by the engine.
 */
public record TradeResult(
        long tradeId,
        long userId,
        String ticker,
        Side side,
        long quantity,
        BigDecimal price,
        BigDecimal realizedPnl,   // non-zero only on SELL that closes a lot
        long latencyMillis
) {
    @Override
    public String toString() {
        return String.format(
            "[TradeResult] id=%d user=%d %s %d %s @ $%s | realizedP&L=$%s | latency=%dms",
            tradeId, userId, side, quantity, ticker, price.toPlainString(),
            realizedPnl.toPlainString(), latencyMillis
        );
    }
}
