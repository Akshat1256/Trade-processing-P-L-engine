package com.tradeengine.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * A single ticker position in a user's portfolio, including MTM P&L.
 */
public record Holding(
        String ticker,
        long netQuantity,           // negative = short
        BigDecimal realizedPnl,
        BigDecimal unrealizedPnl,   // (ltp - avgCost) * netQty
        BigDecimal lastPrice,
        BigDecimal avgCostBasis     // FIFO weighted avg of remaining lots
) {
    public BigDecimal totalPnl() {
        return realizedPnl.add(unrealizedPnl).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public String toString() {
        String dir = netQuantity >= 0 ? "LONG" : "SHORT";
        return String.format(
            "  %-6s  %s %6d  avgCost=$%-10s  ltp=$%-10s  realized=$%-10s  unrealized=$%-10s  total=$%s",
            ticker, dir, Math.abs(netQuantity),
            avgCostBasis.setScale(2, RoundingMode.HALF_UP).toPlainString(),
            lastPrice.setScale(2, RoundingMode.HALF_UP).toPlainString(),
            realizedPnl.setScale(2, RoundingMode.HALF_UP).toPlainString(),
            unrealizedPnl.setScale(2, RoundingMode.HALF_UP).toPlainString(),
            totalPnl().toPlainString()
        );
    }
}
