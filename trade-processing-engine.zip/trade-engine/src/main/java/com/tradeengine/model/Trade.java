package com.tradeengine.model;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Represents a trade execution request.
 * Immutable value object - validated before processing.
 */
public record Trade(
        long userId,
        String ticker,
        Side side,
        long quantity,    // always positive; side determines direction
        BigDecimal price  // BigDecimal - never float/double for money
) {
    public Trade {
        if (quantity <= 0)
            throw new IllegalArgumentException("Quantity must be positive, got: " + quantity);
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Price must be positive, got: " + price);
        if (ticker == null || ticker.isBlank())
            throw new IllegalArgumentException("Ticker must not be blank");
    }

    /** Notional value of this trade. */
    public BigDecimal notional() {
        return price.multiply(BigDecimal.valueOf(quantity));
    }
}
