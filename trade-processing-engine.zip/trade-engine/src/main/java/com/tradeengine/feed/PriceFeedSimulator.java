package com.tradeengine.feed;

import com.tradeengine.db.MarketDataRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simulates a real-time market price feed.
 *
 * Uses a Geometric Brownian Motion (GBM) model — the same mathematical
 * model used for option pricing (Black-Scholes). Each tick:
 *   new_price = old_price * exp(drift + volatility * Z)
 * where Z is a standard normal random variable.
 *
 * Runs on a ScheduledExecutorService, updating prices in market_data
 * every TICK_INTERVAL_MS milliseconds.
 */
public class PriceFeedSimulator {

    private static final Logger log = LoggerFactory.getLogger(PriceFeedSimulator.class);

    private static final long TICK_INTERVAL_MS = 1_000;  // 1 second tick
    private static final double ANNUAL_VOLATILITY = 0.30;  // 30% annualized vol
    private static final double SECONDS_PER_YEAR = 252.0 * 6.5 * 3600;
    // Per-tick volatility scaled from annual
    private static final double TICK_VOL = ANNUAL_VOLATILITY * Math.sqrt(TICK_INTERVAL_MS / 1000.0 / SECONDS_PER_YEAR);

    private final MarketDataRepository repo;
    private final ScheduledExecutorService scheduler;
    private final Random rng = new Random();
    // In-memory price cache to avoid a DB read on every tick
    private final ConcurrentHashMap<String, BigDecimal> priceCache = new ConcurrentHashMap<>();
    private ScheduledFuture<?> task;

    public PriceFeedSimulator(DataSource ds) {
        this.repo = new MarketDataRepository(ds);
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "price-feed");
            t.setDaemon(true);
            return t;
        });
    }

    /** Starts the price feed. Loads current prices from DB first. */
    public void start() {
        try {
            priceCache.putAll(repo.getAllPrices());
            log.info("Price feed starting. Loaded {} tickers: {}", priceCache.size(), priceCache.keySet());
        } catch (Exception e) {
            log.error("Failed to load initial prices", e);
        }

        task = scheduler.scheduleAtFixedRate(this::tick,
                TICK_INTERVAL_MS, TICK_INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        if (task != null) task.cancel(false);
        scheduler.shutdown();
        log.info("Price feed stopped");
    }

    /** Returns the latest in-memory price for a ticker (faster than a DB hit). */
    public BigDecimal getLatestPrice(String ticker) {
        return priceCache.get(ticker);
    }

    // ---------------------------------------------------------------
    // Tick logic
    // ---------------------------------------------------------------

    private void tick() {
        priceCache.forEach((ticker, currentPrice) -> {
            try {
                BigDecimal newPrice = nextPrice(currentPrice);
                priceCache.put(ticker, newPrice);
                repo.updatePrice(ticker, newPrice);
                log.debug("Price update: {} ${} → ${}", ticker,
                        currentPrice.setScale(2, RoundingMode.HALF_UP),
                        newPrice.setScale(2, RoundingMode.HALF_UP));
            } catch (Exception e) {
                log.warn("Failed to update price for {}", ticker, e);
            }
        });
    }

    /**
     * Geometric Brownian Motion step.
     * Ensures price can never go negative (it won't in practice with small vol).
     */
    private BigDecimal nextPrice(BigDecimal current) {
        double z = rng.nextGaussian();   // standard normal
        double factor = Math.exp(TICK_VOL * z);
        double newPriceDouble = current.doubleValue() * factor;
        // Floor at $0.01
        newPriceDouble = Math.max(0.01, newPriceDouble);
        return BigDecimal.valueOf(newPriceDouble)
                .setScale(6, RoundingMode.HALF_UP);
    }
}
