# Trade Processing Engine

A production-grade HFT-adjacent trade processing engine in Java 21.

## Features

| Feature | Implementation |
|---|---|
| FIFO P&L matching | Lot table, consumed in chronological order |
| Mark-to-Market (MTM) | Background GBM price feed, unrealized P&L on every portfolio read |
| Thread safety | Per-user `ReentrantLock` + `ConcurrentHashMap` |
| Atomic DB writes | JDBC transactions (`autoCommit=false`) |
| Financial precision | `BigDecimal` everywhere, `HALF_UP` rounding |
| Connection pooling | HikariCP with `rewriteBatchedStatements=true` |
| Batch processing | 100-trade buffer, flush on size or time interval |
| Crash recovery | Reconciliation by replaying `trades` log |
| Latency tracking | p50/p95/p99 percentile stats |
| Virtual threads | Java 21 `newVirtualThreadPerTaskExecutor` for batch concurrency |
| Circuit breaker | Rejects trades >20% from LTP |

---

## Project Structure

```
trade-engine/
├── pom.xml
└── src/
    ├── main/
    │   ├── java/com/tradeengine/
    │   │   ├── model/
    │   │   │   ├── Trade.java          # Immutable execution record
    │   │   │   ├── TradeResult.java    # Engine output
    │   │   │   ├── Holding.java        # Portfolio line item
    │   │   │   ├── Lot.java            # FIFO share lot
    │   │   │   └── Side.java           # BUY / SELL enum
    │   │   ├── db/
    │   │   │   ├── TradeRepository.java     # All JDBC - trades, lots, positions
    │   │   │   └── MarketDataRepository.java
    │   │   ├── engine/
    │   │   │   ├── TradeEngine.java         # Core processing + P&L engine
    │   │   │   └── BatchTradeProcessor.java # Buffered batch flusher
    │   │   ├── feed/
    │   │   │   └── PriceFeedSimulator.java  # GBM background price thread
    │   │   ├── pool/
    │   │   │   └── ConnectionPool.java      # HikariCP singleton
    │   │   ├── util/
    │   │   │   └── LatencyTracker.java      # p50/p95/p99 percentiles
    │   │   └── cli/
    │   │       └── TradeCLI.java            # Interactive CLI entry point
    │   └── resources/
    │       ├── schema.sql
    │       ├── db.properties
    │       └── logback.xml
    └── test/
        └── java/com/tradeengine/
            └── TradeEngineTest.java     # JUnit 5 + H2 in-memory DB
```

---

## Setup

### Prerequisites
- Java 21+
- Maven 3.9+
- MySQL 8+ (or MariaDB 10.6+)

### 1. Database setup

```bash
mysql -u root -p < src/main/resources/schema.sql
```

### 2. Configure credentials

Edit `src/main/resources/db.properties`:
```properties
db.url=jdbc:mysql://localhost:3306/trade_engine?useSSL=false&serverTimezone=UTC
db.user=root
db.password=yourpassword
```

### 3. Build

```bash
mvn clean package -DskipTests
```

### 4. Run

```bash
java --enable-preview -jar target/trade-processing-engine-1.0.0.jar
```

### 5. Run tests (H2 in-memory — no MySQL needed)

```bash
mvn test
```

---

## CLI Usage

```
trade <userId> <BUY|SELL> <qty> <ticker> <price>
    e.g.  trade 1 BUY 100 AAPL 185.50

portfolio <userId>
    Show holdings with realized + unrealized P&L

prices
    Show current simulated market prices (updates every 1s)

latency
    Show trade processing latency stats (p50 / p95 / p99)

reconcile
    Rebuild positions from trade log (crash recovery)

demo
    Run a quick multi-trade simulation for user 1

quit
```

### Example session

```
trade 1 BUY 100 AAPL 185.00
trade 1 BUY  50 AAPL 187.50    ← second lot at different price
trade 1 BUY  30 TSLA 172.00
trade 1 SELL 80 AAPL 192.00    ← FIFO: realizes P&L from lot 1 first
portfolio 1
latency
```

---

## Architecture Deep Dive

### Trade Lifecycle

```
Trade Object
    → Validator (price circuit breaker, non-zero qty, known ticker)
    → acquire per-user ReentrantLock
    → BEGIN TRANSACTION
        → INSERT trades (immutable log)
        → BUY:  INSERT lots + UPSERT positions (+qty, realized=0)
          SELL: consume lots FIFO → compute realizedPnl
                UPSERT positions (-qty, +realizedPnl)
    → COMMIT  (or ROLLBACK on any failure)
    → release lock
    → return TradeResult
```

### FIFO P&L Example

```
BUY  100 AAPL @ $180  →  Lot A: 100 shares, cost $180
BUY   50 AAPL @ $190  →  Lot B:  50 shares, cost $190

SELL 120 AAPL @ $200:
  Consume Lot A: 100 shares → realized = (200-180) * 100 = $2,000
  Consume Lot B:  20 shares → realized = (200-190) *  20 = $200
  Total realized P&L = $2,200
  Remaining: Lot B has 30 shares open @ $190 avg cost
```

### Thread Safety Model

```
User A ──┐
         ├──► Lock(userId=1) ──► DB Transaction ──► Commit
User A ──┘  (serialized)

User B ────────────────────► Lock(userId=2) ──► DB Transaction ──► Commit
                             (concurrent with User A)
```

Two trades for the same user are serialized by their per-user `ReentrantLock`.  
Two trades for different users run fully concurrently.

### Price Feed (Geometric Brownian Motion)

```
new_price = old_price × exp(σ × Z)

where:
  σ = per-tick volatility (30% annual, scaled to 1s ticks)
  Z = standard normal random variable
```

This is the same model underlying Black-Scholes option pricing.

---

## Key Design Decisions

**Why not an ORM?**  
Raw JDBC gives precise control over transaction boundaries, batching, and query plans. In latency-sensitive paths, ORM overhead (reflection, dirty checking, session management) is measurable.

**Why per-user locks instead of a single global lock?**  
A global lock serializes all trades system-wide. Per-user locks only serialize trades for the *same* user, allowing full concurrency across the user space.

**Why FIFO over average cost?**  
FIFO matches how most brokerages and accounting standards (GAAP) recognize gains and losses. Average cost is simpler but loses lot-level traceability needed for tax lot reporting and audit.

**Why `BigDecimal` with explicit `RoundingMode`?**  
`double` has ~15 significant digits of precision and cannot represent most decimal fractions exactly. On 1 million shares, a $0.000001 rounding error per share = $1 discrepancy. In trading, that's a P&L reporting error and potentially a regulatory issue.

---

## Extending the System

| Extension | Where to add |
|---|---|
| REST API | Add a `TradeController` layer on top of `TradeEngine` (Spring Boot / Javalin) |
| WebSocket live P&L | Subscribe to price feed events, push portfolio updates |
| Risk limits | Add pre-trade checks in `TradeEngine.validateTrade()` |
| Multiple cost methods | Swap FIFO lot consumer for LIFO or Spec ID strategy |
| Metrics | Wire `LatencyTracker` into Micrometer / Prometheus |
| Event sourcing | Replace position table with a trade event log + projections |
